#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <sdkddkver.h>
#include <windows.h>
