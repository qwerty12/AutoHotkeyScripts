#include "avrf.h"
#include <MinHook.h>
#include <io.h>

typedef int(_cdecl *P_ISATTY)(int);
P_ISATTY fp_isatty = NULL;

int _cdecl _isattyHook(int _FileHandle) {
	return _FileHandle != 1 ? fp_isatty(_FileHandle) : TRUE; //stdout
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved)
{
	UNREFERENCED_PARAMETER(lpReserved);
	switch (fdwReason)
	{
	case DLL_PROCESS_ATTACH:
		__security_init_cookie();
		DisableThreadLibraryCalls(hinstDLL);
		if (MH_Initialize() == MH_OK)
			if (MH_CreateHook(_isatty, _isattyHook, (LPVOID*)&fp_isatty) == MH_OK)
				MH_EnableHook(_isatty);
		break;
	case DLL_PROCESS_DETACH:
		MH_Uninitialize();
		break;
	default:
		break;
	}

	return TRUE;
}
